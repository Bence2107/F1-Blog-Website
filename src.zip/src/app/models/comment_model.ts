export interface CommentModel {
  id: number;
  articleUrl: string;
  userid: number;
  content: string;
  timestamp: string;
}
