export interface NewsListModel {
  id: number;
  url: string;
  label: string;
  summary: string;
}
