import { Component } from '@angular/core';
import { MatSnackBarRef } from '@angular/material/snack-bar';
import {MatButton} from '@angular/material/button';



@Component({
  selector: 'app-custom-snackbar',
  imports: [
    MatButton
  ],
  template: `
    <div class="custom-snackbar">
      <span>Sikeres Bejelentkezés</span>
      <button mat-flat-button (click)="dismiss()">Oké</button>
    </div>
  `,
  styles: [`
    .custom-snackbar {
      display: flex;
      justify-content: space-between;
      align-items: center;
      color: var(--primary-text);
      background-color: var(--secondary-background);
      padding: 10px;
      border-radius: 5px;
      font-size: 14px;
    }
  `],

})
export class CustomSnackbarComponent {
  constructor(public snackBarRef: MatSnackBarRef<CustomSnackbarComponent>) {}

  dismiss() {
    this.snackBarRef.dismiss();
  }
}
