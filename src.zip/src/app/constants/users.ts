import {UserModel} from '../models/user_model';

export const users_list : UserModel[] = [
  {
    id: 1,
    email: "szabobence003@gmail.com",
    username: "Bence2107",
    avatarUrl: "1.jpg"
  },
  {
    id: 2,
    email: "hurajongok@gmail.com",
    username: "SzevaszVer"
  }
]
